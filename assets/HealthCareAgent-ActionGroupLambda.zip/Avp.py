import boto3

avp = boto3.client("verifiedpermissions")
POLICY_STORE_ID = "<POLICY_STORE_ID>"


def is_authorized(agent: str, role: str, patient: str) -> bool:
    try:
        action = "ReadPatientMedicalData"
        authzDecision = None

        authorizationQuery = {
            "policyStoreId": POLICY_STORE_ID,
            "principal": {"entityType": "HealthCareAgent::Agent", "entityId": agent},
            "action": {"actionType": "HealthCareAgent::Action", "actionId": action},
            "resource": {"entityType": "HealthCareAgent::Patient", "entityId": patient},
            "entities": buildEntities(agent, role, patient),
        }

        authZResult = avp.is_authorized(**authorizationQuery)
        authzDecision = authZResult.get("decision")
    except Exception as e:
        print(e)
    finally:
        response = False
        if authzDecision == "ALLOW":
            response = True

        return response


"""----------------build entities structure---------------------"""
def buildEntities(agent: str, role: str, patient: str):
    entities = {
        "entityList": [
            {
                "identifier": {
                    "entityType": "HealthCareAgent::Agent",
                    "entityId": agent,
                },
                "attributes": {},
                "parents": [{"entityType": "HealthCareAgent::Role", "entityId": role}],
            },
            {
                "identifier": {
                    "entityType": "HealthCareAgent::Patient",
                    "entityId": patient,
                },
                "attributes": {},
                "parents": [],
            },
        ]
    }

    return entities
