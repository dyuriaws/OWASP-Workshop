import json
import Database
import Avp

def get_named_parameter(event, name):
    return next(item for item in event["parameters"] if item["name"] == name)["value"]


def get_named_property(event, name):
    return next(
        item
        for item in event["requestBody"]["content"]["application/json"]["properties"]
        if item["name"] == name
    )["value"]


def get_session_attributes(event):
    agentName = None
    sessionAttr = event["sessionAttributes"]

    if "agentName" in sessionAttr:
        agentName = sessionAttr["agentName"]

    return agentName


def get_prompt_session_attributes(event):
    agentName = None
    promptSessionAttr = event["promptSessionAttributes"]

    if "agentName" in promptSessionAttr:
        agentName = promptSessionAttr["agentName"]

    return agentName


def get_patient_info(event) -> str:
    # Get the patient's contact data
    patient = get_named_parameter(event, "name")
    pData = Database.get_patient(patient)

    # Get the patient's medical data
    mData = Database.get_medical_data(patient)
    pData.medicaldata = mData

    return pData


def lambda_handler(event, context):
    print(event)
    print(context)

    result = None
    response_code = 200
    action_group = event["actionGroup"]
    api_path = event["apiPath"]

    if api_path == "/getpatientinfo":
        result = get_patient_info(event)
    else:
        print("Unrecognized api path")
        response_code = 404
        result = f"Unrecognized api path: {action_group}::{api_path}"

    response_body = {"application/json": {"body": json.dumps(result, default=lambda o: o.__dict__)}}

    action_response = {
        "actionGroup": event["actionGroup"],
        "apiPath": event["apiPath"],
        "httpMethod": event["httpMethod"],
        "httpStatusCode": response_code,
        "responseBody": response_body,
    }

    api_response = {"messageVersion": "1.0", "response": action_response}
    return api_response
