import boto3
from Model import Patient, MedicalData, Agent

dynamodb = boto3.resource("dynamodb")
role_table = dynamodb.Table("healthcareagentinfo")
patient_table = dynamodb.Table("healthcarepatientinfo")
medical_data_table = dynamodb.Table("healthcarepatientphiinfo")


def get_role(name: str) -> Agent:
    item = role_table.get_item(Key={"name": name.lower()})["Item"]
    return Agent.from_item(item)


def get_patient(name: str) -> Patient:
    item = patient_table.get_item(Key={"name": name.lower()})["Item"]
    return Patient.from_item(item)


def get_medical_data(name: str) -> MedicalData:
    item = medical_data_table.get_item(Key={"name": name.lower()})["Item"]
    return MedicalData.from_item(item)
