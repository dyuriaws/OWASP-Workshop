from dataclasses import dataclass


@dataclass
class MedicalData:
    bloodpressure: str
    bloodtype: str
    hdl: int
    ldl: int
    triglycerides: int

    @classmethod
    def from_item(cls, item):
        return MedicalData(
            bloodpressure=item["bloodpressure"],
            bloodtype=item["bloodtype"],
            hdl=int(item["hdl"]),
            ldl=int(item["ldl"]),
            triglycerides=int(item["triglycerides"]),
        )


@dataclass
class Patient:
    name: str
    dob: str
    address: str
    phonenumber: str
    medicaldata: MedicalData = None

    @classmethod
    def from_item(cls, item):
        return Patient(
            name=item["name"],
            dob=item["dob"],
            address=item["address"],
            phonenumber=item["phonenumber"],
        )


@dataclass
class Agent:
    name: str
    role: str

    @classmethod
    def from_item(cls, item):
        return Agent(name=item["name"], role=item["role"])
